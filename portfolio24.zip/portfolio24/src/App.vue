<script setup>
import { RouterLink, RouterView } from 'vue-router'

</script>


<!-- SVG DRAW WITH DASH :)) -->


<template>

  <!-- <div class="h-screen bg-slate-100 ">
    <svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 129.1 73.93" width="400" height="200">
      <path class="cls-1" d="M9.87,73.75S-24.76-16.97,39.14,3.51s-18.55,63.9,38.77,65.85,52.93-5.37,48.06-27.8"/>
    </svg> 
  </div>  -->

  <RouterView />
</template>

<style scoped> 
/* .cls-1 {
  fill: none;
  stroke: #be1e2d;
  stroke-miterlimit: 10;
  stroke-dasharray: 275;
  stroke-dashoffset: 275;
  transition: stroke-dashoffset 1s ease;
}

.h-screen:hover .cls-1{
  stroke-dashoffset: 0;
} */
</style>

